﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace CRUD_Demo_SP
{
    public partial class Home : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                getAllEmployeeList();
            }

        }

        SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-JE87Q97\SQLEXPRESS;Initial Catalog=Demo_crud;Integrated Security=True");
        protected void Button1_Click(object sender, EventArgs e)
        {
            int EmployeeId = int.Parse(TextBox1.Text);
            string EmpName = TextBox5.Text;
            string City = TextBox6.Text;
            string Email = TextBox7.Text;
            con.Open();
            SqlCommand cmd = new SqlCommand("exec EmployeeInsert '" + EmployeeId + "','" + EmpName + "','" + City + "','" + Email + "'", con);
            cmd.ExecuteNonQuery();
            con.Close();
            ScriptManager.RegisterStartupScript(this, this.GetType(), "script", "alert('sucessfully inserted');",true);
            getAllEmployeeList();
        }

        void getAllEmployeeList()
        {
            SqlCommand cmd = new SqlCommand(" exec EmployeeShow ", con);
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            GridView1.DataSource = dt;
            GridView1.DataBind();
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            int EmployeeId = int.Parse(TextBox1.Text);
            string EmpName = TextBox5.Text;
            string City = TextBox6.Text;
            string Email = TextBox7.Text;
            con.Open();
            SqlCommand cmd = new SqlCommand("exec EmployeeUpdate '" + EmployeeId + "','" + EmpName + "','" + City + "','" + Email + "'", con);
            cmd.ExecuteNonQuery();
            con.Close();
            ScriptManager.RegisterStartupScript(this, this.GetType(), "script", "alert('sucessfully updated');", true);
            getAllEmployeeList();
        }

        protected void Button3_Click(object sender, EventArgs e)
        {
            int EmployeeId = int.Parse(TextBox1.Text);
            con.Open();
            SqlCommand cmd = new SqlCommand("exec EmployeeDelete '" + EmployeeId + "'", con);
            cmd.ExecuteNonQuery();
            con.Close();
            ScriptManager.RegisterStartupScript(this, this.GetType(), "script", "alert('sucessfully Deleted ');", true);
            getAllEmployeeList();

        }
    }
}